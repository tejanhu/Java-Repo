package maintenancebookings;

public class MoT extends ScheduleMaintenance {

      private boolean fail;

    MoT() {
        super(30);
        
    }
}
