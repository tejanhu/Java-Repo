package maintenancebookings;

public class Bays {

	
         final int maximum_amount=6;
                 
	public Bays(int total_amount) {
		total_amount=maximum_amount;
	}

        
	
	public int getBaycount(int total_amount) {
	/*if(selectBay){
            total_amount=maximum_amount-1;
            return total_amount;
        }
        */        
            return total_amount;
            
	}

}