package maintenancebookings;

import java.util.ArrayList;

public class Service extends ScheduleMaintenance {

    public Service() {
        super(150);
    }

    /**
     *
     * @param service
     */
    public Service getService() {
        return this;

    }

}
