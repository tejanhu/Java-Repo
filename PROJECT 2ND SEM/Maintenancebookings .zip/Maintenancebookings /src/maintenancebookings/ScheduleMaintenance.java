/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package maintenancebookings;

/**
 *
 * @author ht304
 */
public class ScheduleMaintenance {
    private final int cost;
    
    public ScheduleMaintenance(int sum){
        cost=sum;
    }
}
