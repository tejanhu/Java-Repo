/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package maintenancebookings;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author ht304
 */
public class holi_bank implements Holidays{
    ArrayList<Date> bankhodays;

    public ArrayList<Date> getHoDates() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setHoDates(ArrayList<Date> newholidays) {
             
        
        
        
    }

    @Override
    public void addHoDate(Date newholiday) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
    
    
}
