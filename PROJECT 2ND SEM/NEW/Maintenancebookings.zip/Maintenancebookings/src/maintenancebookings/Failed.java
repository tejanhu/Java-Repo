package maintenancebookings;


import java.util.ArrayList;

public class Failed {

        private int vehicleID;
	private String commentary;

	
	public Failed(ArrayList failed) {
	if()
            
            
	}

}