/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package maintenancebookings;

import java.util.ArrayList;

/**
 *
 * @author ht304
 */
public class Usagebased extends Service  {

    private int miles=0;
    private final int min_miles=10000;
    private final int max_miles=12000;
    
    public Usagebased() {
    }
    
    public void setMiles(int mileage){
        miles=mileage;
    }
    
    @Override
    public Service getService() {
        return this; //To change body of generated methods, choose Tools | Templates.
    }

    
    public int getMiles(int miles, int min_miles, int max_miles) {
        try{
            if(miles<min_miles||miles>max_miles){
            throw new IndexOutOfBoundsException();
            
            
        } //END if
            
            else{
                return miles;
            }
    }//End try
        catch(IndexOutOfBoundsException E){
           
            System.out.println("Sorry Peter..");
            
        }//END catch
     return -1;
}
    
    
}