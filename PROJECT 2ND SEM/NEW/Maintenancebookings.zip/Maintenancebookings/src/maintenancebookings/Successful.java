package maintenancebookings;

public class Successful {

	private int vehicleID;

}