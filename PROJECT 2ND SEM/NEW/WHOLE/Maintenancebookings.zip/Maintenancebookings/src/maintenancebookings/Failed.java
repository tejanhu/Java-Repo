package maintenancebookings;


import java.util.ArrayList;

public class Failed {

        private int vehicleID;
        private int customerID;
        private String vehicle;
        private String make;
        private String manufacturer;
	private String commentary;

	
	public Failed(ArrayList failed) {
	if()
            
            
	}

}