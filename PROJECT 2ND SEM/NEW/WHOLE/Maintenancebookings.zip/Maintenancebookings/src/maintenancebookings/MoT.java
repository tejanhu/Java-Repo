package maintenancebookings;

public class MoT extends ScheduleMaintenance {

      private boolean fail;

    public MoT() {
        super(30);
        
    }
}
