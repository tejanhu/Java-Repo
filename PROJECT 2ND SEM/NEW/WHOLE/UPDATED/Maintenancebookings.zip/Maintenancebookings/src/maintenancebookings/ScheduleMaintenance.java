/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package maintenancebookings;


public class ScheduleMaintenance {
    
    
    private static int tcost;

    /**
     * @return the tcost
     */
    public static int getTcost() {
        return tcost;
    }
    private final int cost;
 
    
    
    public ScheduleMaintenance(int sum){
        cost=sum;   
        tcost=sum;
    }

    /**
     * @return the cost
     */
    public int getCost() {
        return cost;
    }
}
