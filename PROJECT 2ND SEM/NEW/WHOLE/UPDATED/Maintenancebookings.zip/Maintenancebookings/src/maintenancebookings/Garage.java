package maintenancebookings;

import java.util.Date;

public class Garage {
    
    public boolean isHoliday(){
               
        if(Schedule().getDate().equals(holi_bank)){
            
        }
    }
    
}