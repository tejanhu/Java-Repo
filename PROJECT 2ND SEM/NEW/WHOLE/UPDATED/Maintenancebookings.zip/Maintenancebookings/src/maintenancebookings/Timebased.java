/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maintenancebookings;

import java.util.ArrayList;

/**
 *
 * @author ht304
 */
public class Timebased extends Service  {

    private int year;

    public Timebased(int yr) throws IndexOutOfBoundsException {

        if (yr < 1 || yr > 2) {
            throw new IndexOutOfBoundsException();
        } else {
            year = yr;
        }
    }

    
    @Override
    public Service getService() {
        return this; //To change body of generated methods, choose Tools | Templates.
    }

  

    public int getYear() {

        return year;

    }

   

}
