package maintenancebookings;

import java.sql.Time;
import java.util.Date;

public class Schedule {

  
    
	private Time time;
	private Date date;

    public Schedule(Time time, Date date) {
        this.time = time;
        this.date = date;
    }
        
    
	public Time getTime() {
		return this.time;
	}

	
	public void setTime(Time time) {
		this.time = time;
	}

	public Date getDate() {
		return this.date;
	}

	/**
	 * 
	 * @param date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	
//	public void setBaycount(int total_amount) {
//		// TODO - implement Schedule.setBaycount
//		throw new UnsupportedOperationException();
//	}
        
        
        

}