package maintenancebookings;

public class Successful {

    private int vehicleID;
    private int customerID;
    private String vehicle;
    private String make;
    private String manufacturer;

}
