package weatherapp.view;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import org.tbee.javafx.scene.layout.MigPane;

public class porty extends Application {

    @Override
    public void start(Stage primaryStage) {

        MigPane maincont = new MigPane("insets 0,debug, wrap,gap 0,hidemode 2", "[]", "[][]");

        maincont.add(getTopblock(), "width 320, height 310,dock north");
        maincont.add(getBotBlock(), "width 320, height 170,dock south");
        Scene scene = new Scene(maincont, 320, 480);

        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.resizableProperty().set(false);
        primaryStage.sizeToScene();
        primaryStage.show();
    }

    public MigPane getBotBlock() {
        MigPane Botblock = new MigPane("debug,nogrid,flowy");
        Font somefFont = new Font("Verdana", 14);
        Label lblnow = new Label("Now");
        Label lblTow = new Label("Tom");
        Label lblWed = new Label("Wed");
        Label degree = new Label("15");
        Label degree2 = new Label("15");
        Label degree3 = new Label("15");
        Separator someseparator = new Separator(Orientation.VERTICAL);
        Separator someseparator2 = new Separator(Orientation.VERTICAL);
        Separator someseparator3 = new Separator(Orientation.VERTICAL);

        someseparator.setPrefHeight(170);
        someseparator2.setPrefHeight(170);
        someseparator3.setPrefHeight(170);

        lblnow.setFont(somefFont);
        lblTow.setFont(somefFont);
        lblWed.setFont(somefFont);
        Image thecloud = new Image("weatherapp/view/misty cloud or windy for land.png");
        ImageView cloud = new ImageView(thecloud);
        Image thecloud2 = new Image("weatherapp/view/misty cloud or windy for land.png");
        ImageView cloud2 = new ImageView(thecloud);
        Image thecloud3 = new Image("weatherapp/view/misty cloud or windy for land.png");
        ImageView cloud3 = new ImageView(thecloud);
        Botblock.add(lblnow, "center");
        Botblock.add(degree, "gaptop -5px,center");
        Botblock.add(cloud, "center,wrap");
        Botblock.add(someseparator);
        Botblock.add(lblTow, "center");
        Botblock.add(degree2, "gaptop -5px,center");
        Botblock.add(cloud2, "center,wrap");
        Botblock.add(someseparator2);

        Botblock.add(lblWed, "center");
        Botblock.add(degree3, "gaptop -5px,center");
        Botblock.add(cloud3, "center,wrap");
//       Botblock.add(someseparator3);

        Botblock.getStylesheets().add(porty.class.getResource("Weatherport.css").toExternalForm());
        Botblock.setId("boty");
        return Botblock;
    }

    public MigPane getTopblock() {
        MigPane topblock = new MigPane();
        topblock.getStylesheets().add(porty.class.getResource("Weatherport.css").toExternalForm());
        topblock.setId("topy");

        return topblock;
    }

    public static void main(String[] args) {
        launch(args);
    }

}
