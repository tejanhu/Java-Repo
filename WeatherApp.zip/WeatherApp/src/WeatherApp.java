/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.stage.Stage;
import org.controlsfx.control.SegmentedButton;
import org.tbee.javafx.scene.layout.MigPane;

/**
 *
 * @author ht304
 */
/*
 ____________________________________________________________
 |                                              
 |
 |
 |
 |
 |
 |
 |
 |
 |
 ___________ |
 |
 |
 |
 |
 |
 |
 ___________________________________________________________

 */
public class WeatherApp extends Application {

    @Override
    public void start(Stage primaryStage) {

        MigPane main = new MigPane("insets 0,gap 0, wrap2", "[grow] []", "[][]");
        main.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        main.setId("mainy");

        MigPane left = new MigPane("gap 0,insets 0","[grow]","[]");
        left.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        left.setId("left");

        MigPane right = new MigPane("wrap2", "[grow] 10 [grow]", "[]14[][][][][]");
        right.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        right.setId("right");

        MigPane bottom = new MigPane();
        bottom.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        bottom.setId("bottom");
        Label lbl1 = new Label("Settings");
        lbl1.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        lbl1.setId("settings_col");

        main.add(left, "width 38, height 353,growy 5");
        main.add(right, "width 282, height 400");
        main.add(bottom, "gaptop 4px,width 38, height 123");

        Label lbl2 = new Label("Temp Metric");
        lbl2.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        lbl2.setId("settings_col");
        
        Label lbl3 = new Label("Set time");
        lbl3.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        lbl3.setId("settings_col");
        
        Label lbl4 = new Label("Set locations");
        lbl4.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        lbl4.setId("settings_col");
        
        Label lbl5 = new Label("Orientation");
        lbl5.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        lbl5.setId("settings_col");
        
        Label lbl6 = new Label("Tooltips");
        lbl6.getStylesheets().add(WeatherApp.class.getResource("sety.css").toExternalForm());
        lbl6.setId("settings_col");
        
        ToggleButton menu=new ToggleButton();
        
        left.add(menu, "center");
        
        
        
        ToggleButton degrees = new ToggleButton("°C");
        ToggleButton farenheit = new ToggleButton("°F");

        SegmentedButton temp = new SegmentedButton();
        temp.getButtons().addAll(degrees, farenheit);

        ToggleButton letemp = new ToggleButton("am");
        ToggleButton letemp2 = new ToggleButton("pm");

        SegmentedButton time = new SegmentedButton();
        time.getButtons().addAll(letemp, letemp2);

        ComboBox locality = new ComboBox();
        //locality.g
        ToggleButton land = new ToggleButton("Landscape");
        ToggleButton port = new ToggleButton("Portrait");

        SegmentedButton orientopt = new SegmentedButton();
        orientopt.getButtons().addAll(land, port);

        ToggleButton dis = new ToggleButton("Disable");
        ToggleButton en = new ToggleButton("Enable");

        SegmentedButton tt = new SegmentedButton();
        tt.getButtons().addAll(dis, en);
        //Settings
        right.add(lbl1, "span, center, grow");
        //temp metric
        right.add(lbl2);
        //cels_faren
        right.add(temp);
        //set time
        right.add(lbl3);
        //time
        right.add(time);
        //set locations
        right.add(lbl4);
        //combo box
        right.add(locality);
        //set orientation
        right.add(lbl5);
        right.add(orientopt);
        right.add(lbl6);
        right.add(tt);

        Scene scene = new Scene(main, 320, 480);

        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.resizableProperty().set(false);
        primaryStage.sizeToScene();
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
