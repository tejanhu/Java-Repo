package maintenancebookings;

public class MoT extends MaintenanceBooking {

      private boolean fail;

    public MoT() {
        super(30);
        
    }
}
