package maintenancebookings;


public class Service extends MaintenanceBooking {

    public Service() {
        super(150);
    }

    /**
     *
     * @param service
     */
    public Service getService() {
        return this;

    }

}
