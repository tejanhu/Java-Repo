/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maintenancebookings;

import java.util.ArrayList;

/**
 *
 * @author ht304
 */
public interface  ScheduledMaintenance {

    
    
//    Holidays holidates = new holi_public();
//    Holidays bankdates = new holi_bank();
    

//    ArrayList service=new <Service>ArrayList();
    
//    public static void main(String[] args) {
//       
//        
//        
//    }

}
