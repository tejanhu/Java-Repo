/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maintenancebookings;

import java.util.ArrayList;

/**
 *
 * @author LatinoWolofKid
 */
public class SMB {

    private ArrayList<MaintenanceBooking> crap;

    public SMB() {
        this.crap = new ArrayList();

        
        
        
    }

    public void makeUsageBasedServiceBooking() {
        crap.add( new Usagebased());
        
    }

    public void makeTimeBasedBooking(int year) {
        crap.add(new Timebased(year));
    }

    public void makeMaintenanceBooking() {
        crap.add( new MoT());
        
    }

    public void removeBooking(MaintenanceBooking bookingToBeRemoved) {
        crap.remove(bookingToBeRemoved);
        
    }

    public static void main(String[] args) {

    }

    /**
     * @return the crap
     */
    public ArrayList<MaintenanceBooking> getCrap() {
        return crap;
    }

}
