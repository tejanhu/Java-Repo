/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maintenancebookings;

import java.util.ArrayList;

/**
 *
 * @author ht304
 */
public class Usagebased extends Service {

    private int miles = 0;
    private final int min_miles = 10000;
    private final int max_miles = 12000;
    private  int diffOfMiles=0;
    private int vehicleID;
    private String bookingType;

    /**
     *
     */
    public Usagebased() {
    }

    public void setVehicleID(int vID) {
        vehicleID = vID;
    }

    public void setBookingType(String bType) {
        bookingType = bType;
    }

    public void setMiles(int mileage) {
        miles = mileage;
    }
    
    public  void setDifference(int previousMiles){
        diffOfMiles=previousMiles-miles;
    }

    public int getVehicleID() {
        return vehicleID;
    }

    public String getBookingType() {
        return bookingType;
    }

    @Override
    public Service getService() {
        return this; //To change body of generated methods, choose Tools | Templates.
    }

    public int getDifference(int miles, int min_miles, int max_miles) {
        try {
            if (diffOfMiles < min_miles || diffOfMiles > max_miles) {
                throw new IndexOutOfBoundsException();

            } //END if
            else {
                return diffOfMiles;
            }
        }//End try
        catch (IndexOutOfBoundsException E) {

            System.out.println("Sorry Peter..");

        }//END catch
        return -1;
    }

}
